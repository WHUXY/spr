#include <stdio.h>

int foo() {
    return 1;
}

int main() {
    printf("%d\n", foo());
    return 0;
}
