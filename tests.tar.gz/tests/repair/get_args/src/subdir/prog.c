#include "a.h"
#include <stdio.h>

int foo() {
    return ONE;
}

int main() {
    printf("%d\n", foo());
    return 0;
}
