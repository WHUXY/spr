#define DIVIDE(res, a, b) \
do { \
    (res) = (a) / (b); \
} while (0)
