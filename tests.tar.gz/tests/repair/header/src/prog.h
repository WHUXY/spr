static long foo(long a, long b) {
    long ret = 0;
    ret = a/b;
    return ret + 1;
}
