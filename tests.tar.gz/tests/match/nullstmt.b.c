int main() {
    int a = 0;
    return 0;
}
