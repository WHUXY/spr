void myprintf(const char *a) {
}

int main() {
    myprintf("bbb");
    return 0;
}
