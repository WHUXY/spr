int main() {
    int a = 0;
    int b = 1;
    a = a + b;
    return 0;
}
