int main() {
    goto succ;
fail:
    return 1;
succ:
    return 0;
}
