int main() {
    int a;
    return a;
}
