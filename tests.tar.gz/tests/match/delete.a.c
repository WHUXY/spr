int main() {
    int a;
    a = 0;
    return a;
}
