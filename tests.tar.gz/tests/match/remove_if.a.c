int main() {
    int a = 0;
    int b;
    if (a == 0) {
        b = a;
        b ++;
        b ++;
        return b;
    }
    return 0;
}
