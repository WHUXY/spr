void myprintf(const char *a) {
}

int main() {
    myprintf("aaa");
    return 0;
}
