#include <stdio.h>

int foo() {
    return 0;
    return 1;
}

int main() {
    printf("%d\n", foo());
    return 0;
}
