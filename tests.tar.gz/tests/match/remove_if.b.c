int main() {
    int a = 0;
    int b;
    return 0;
}
