#include <stdio.h>

int main() {
    int type;
    while (1) {
        scanf("%d", &type);
    }
}
