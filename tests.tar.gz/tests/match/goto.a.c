int main() {
fail:
    return 1;
succ:
    return 0;
}
