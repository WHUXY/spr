int main() {
    int a = 0;
    int b = 10;
    int c = 0;
    if (a != 0)
        c = b/a;
    return 0;
}
