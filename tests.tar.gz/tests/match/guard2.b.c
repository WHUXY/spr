int main() {
    int a = 0;
    int b = 1;
    if (b == 0) {
        a = a + b;
    }
    return 0;
}
