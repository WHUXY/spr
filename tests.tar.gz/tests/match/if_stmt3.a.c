int main() {
    int a = 10;
    int b = 20;
    if (a == 10) {
        if (b == 21) {
            return 1;
        }
    }
}
