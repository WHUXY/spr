void foo(char* x) {
    x[0] = 0;
}

int main() {
    foo("l");
    return 0;
}
