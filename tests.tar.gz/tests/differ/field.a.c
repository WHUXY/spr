struct t {
    int x;
    int y;
};

int main() {
    struct t a;
    a.x = 0;
    return 0;
}
