void foo(char* x) {
    x[0] = 0;
}

int main() {
    foo("i");
    return 0;
}
