int main() {
    int **p;
    return 0;
}
