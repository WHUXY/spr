int main() {
    int a = 0;
    if ((a == 0) || (a == 1))
        return 0;
    return 1;
}
