#!/usr/bin/env python
from sys import argv
from os import path, chdir, getcwd, environ
import subprocess
import getopt


def compileit(out_dir):
    ori_dir = getcwd();
    chdir(out_dir);

    my_env = environ;

    

   
    ret = subprocess.call(["make"], env = my_env);
    if ret != 0:
       print "Failed to make!";
       chdir(ori_dir);
       exit(1);

    chdir(ori_dir);

if __name__ == "__main__":
    opts, args = getopt.getopt(argv[1:],'cd:hlp:r:x');
    if (len(args) < 1):
        print "Usage: simple-build.py <directory> [-d src_file | -l] [-h]";
        exit(0);

    out_dir = args[0];
    print out_dir;
    if (path.exists(out_dir)):
        print "Working with existing directory: " + out_dir;
    else:
        print "Non-exist directory";
        exit(1);

    compileit(out_dir);
    
