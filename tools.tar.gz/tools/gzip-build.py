#!/usr/bin/env python
from sys import argv
from os import path, chdir, getcwd, environ
from tester_common import extract_arguments
import subprocess
import getopt

def fix_configure(configurefile):
    f = open(configurefile, "r");
    lines = f.readlines();
    f.close();
    f = open(configurefile, "w");
    for line in lines:
        if (line.find("m4_esyscmd([build-aux/git-version-gen") != -1):
            f.write("    1.0,\n");
        else:
            f.write(line);
    f.close();

def fix_stdio(stdiofile):
    f = open(stdiofile, "r");
    lines = f.readlines();
    f.close();
    f = open(stdiofile, "w");
    for line in lines:
        if (line.find("_GL_WARN_ON_USE (gets") == 0):
            f.write("//");
        f.write(line);
    f.close();

def fix_conf(conffile):
    f = open(conffile, "r");
    lines = f.readlines();
    f.close();
    f = open(conffile, "w");
    for line in lines:
        if (line.find("perl") == 0):
            f.write("perl\t-\n");
        else:
            f.write(line);
    f.close();

def compileit(out_dir, compile_only = False, config_only = False):
    ori_dir = getcwd();
    chdir(out_dir);

    my_env = environ;

    if not compile_only:
        if (path.exists("configure.ac")):
            fix_configure("configure.ac");
        if (path.exists("bootstrap.conf")):
            fix_conf("bootstrap.conf");
        ret = subprocess.call(["./bootstrap"], shell = True, env = my_env);
        if (ret != 0):
            print "Failed to run bootstrap!!!";
            chdir(ori_dir);
            exit(1);
        if (path.exists("lib/stdio.in.h")):
            fix_stdio("lib/stdio.in.h");
        ret = subprocess.call(["./configure"], shell = True, env = my_env);
        if (ret != 0):
            print "Failed to run configure!";
            chdir(ori_dir);
            exit(1);

    if not config_only:
        ret = subprocess.call(["make"], env = my_env);
        if ret != 0:
            print "Failed to make!";
            chdir(ori_dir);
            exit(1);

    chdir(ori_dir);

if __name__ == "__main__":
    deps_dir = getcwd() + "/gzip-deps"

    compile_only = False;

    opts, args = getopt.getopt(argv[1:],'cd:hlp:r:x');
    dryrun_src = "";

    print_fix_log = False;
    print_usage = False;
    config_only = False;
    for o, a in opts:
        if o == "-d":
            dryrun_src = a;
        elif o == "-p":
            if a[0] == "/":
                deps_dir = a;
            else:
                deps_dir = getcwd() + "/" + a;
        elif o == "-x":
            config_only = True;
        elif o == "-c":
            compile_only = True;
        elif o == "-l":
            print_fix_log = True;
        elif o == "-h":
            print_usage = True;

    if (len(args) < 1) or (print_usage):
        print "Usage: gzip-build.py <directory> [-d src_file | -l] [-h]";
        exit(0);

    out_dir = args[0];
    if (path.exists(out_dir)):
        print "Working with existing directory: " + out_dir;
    else:
        print "Non-exist directory";
        exit(1);

    compileit(out_dir, compile_only, config_only);
    if dryrun_src != "":
        (builddir, buildargs) = extract_arguments(out_dir, dryrun_src);
        if len(args) > 1:
            out_file = open(args[1], "w");
            print >> out_file, builddir;
            print >> out_file, buildargs;
            out_file.close();
        else:
            print builddir;
            print buildargs;
