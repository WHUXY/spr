#! /usr/bin/perl 

print "Content-Type: text/html\r\n\r\n";

print $ENV{"SCRIPT_NAME"};

0;
